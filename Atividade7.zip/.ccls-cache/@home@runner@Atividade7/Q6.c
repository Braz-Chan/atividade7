#include <stdio.h>

int main() {
    int opcao, quantidade;
    float total = 0.0;

    printf("Menu de Frutas:\n");
    printf("1 => ABACAXI – 5,00 a unidade\n");
    printf("2 => MAÇA – 1,00 a unidade\n");
    printf("3 => PERA – 4,00 a unidade\n");
    printf("0 => Sair\n");

    while (1) {
        printf("Digite o número da fruta (ou 0 para sair): ");
        scanf("%d", &opcao);

        if (opcao == 0) {
            break;
        }

        if (opcao < 1 || opcao > 3) {
            printf("Opção inválida. Tente novamente.\n");
            continue;
        }

        printf("Digite a quantidade desejada: ");
        scanf("%d", &quantidade);

        switch (opcao) {
            case 1:
                total += quantidade * 5.0;
                break;
            case 2:
                total += quantidade * 1.0;
                break;
            case 3:
                total += quantidade * 4.0;
                break;
        }
    }

    printf("Total da compra: %.2f\n", total);

    return 0;
}
