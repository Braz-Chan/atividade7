#include <stdio.h>

int main() {
    int N, i, num = 1;
    
    printf("Digite um número inteiro N: ");
    scanf("%d", &N);
    
    for (i = 0; i < N; i++) {
        printf("%d\n", num);
        num += 2;
    }
    
    return 0;
}
