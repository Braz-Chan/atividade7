#include <stdio.h>

int main() {
    int N, i;
    
    printf("Digite um número inteiro positivo N: ");
    scanf("%d", &N);
    
    for (i = 0; i <= N; i++) {
        printf("%d\n", i);
    }
    
    return 0;
}
