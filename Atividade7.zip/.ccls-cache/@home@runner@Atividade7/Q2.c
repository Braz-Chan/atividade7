#include <stdio.h>

int main() {
    int N, i;
    
    printf("Digite um número inteiro positivo N: ");
    scanf("%d", &N);
    
    for (i = N; i >= 0; i--) {
        printf("%d\n", i);
    }
    
    return 0;
}
