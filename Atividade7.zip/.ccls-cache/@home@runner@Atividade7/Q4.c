#include <stdio.h>

int main() {
    int i, num = 3;
    
    printf("Os cinco primeiros múltiplos de 3 são:\n");
    for (i = 0; i < 5; i++) {
        printf("%d\n", num);
        num += 3;
    }
    
    return 0;
}
