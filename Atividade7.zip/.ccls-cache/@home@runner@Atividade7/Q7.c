#include <stdio.h>

int main() {
    char sexo, olhos, cabelos;
    int idade;
    float salario;
    int total_feminino = 0;
    int total_feminino_18_35_castanhos_castanhos = 0;
    
    while (1) {
        printf("Informe o sexo (m/f): ");
        scanf(" %c", &sexo);
        
        if (sexo == 'm' || sexo == 'f') {
            if (sexo == 'f') {
                total_feminino++;
            }
            
            printf("Informe a cor dos olhos (a/v/c/p): ");
            scanf(" %c", &olhos);
            
            if (olhos == 'a' || olhos == 'v' || olhos == 'c' || olhos == 'p') {
                printf("Informe a cor dos cabelos (l/c/p/r): ");
                scanf(" %c", &cabelos);
                
                if (cabelos == 'l' || cabelos == 'c' || cabelos == 'p' || cabelos == 'r') {
                    printf("Informe a idade (entre 10 e 100 anos): ");
                    scanf("%d", &idade);
                    
                    if (idade >= 10 && idade <= 100) {
                        printf("Informe o valor do salário: ");
                        scanf("%f", &salario);
                        
                        if (salario >= 0) {
                            if (sexo == 'f' && idade >= 18 && idade <= 35 && olhos == 'c' && cabelos == 'c') {
                                total_feminino_18_35_castanhos_castanhos++;
                            }
                        } else {
                            printf("Salário negativo não é válido.\n");
                        }
                    } else {
                        printf("Idade fora do intervalo válido.\n");
                    }
                } else {
                    printf("Cor dos cabelos inválida.\n");
                }
            } else {
                printf("Cor dos olhos inválida.\n");
            }
        } else if (sexo == 'fim') {
            break;
        } else {
            printf("Sexo inválido.\n");
        }
    }
    
    float porcentagem_feminino_18_35_castanhos_castanhos = 0.0;
    if (total_feminino > 0) {
        porcentagem_feminino_18_35_castanhos_castanhos = (float)total_feminino_18_35_castanhos_castanhos / total_feminino * 100;
    }
    
    printf("Porcentagem de indivíduos do sexo feminino, entre 18 e 35 anos, com olhos e cabelos castanhos: %.2f%%\n", porcentagem_feminino_18_35_castanhos_castanhos);
    
    return 0;
}
